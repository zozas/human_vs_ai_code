<?php
ini_set("max_execution_time", 0);
//ini_set("display_errors", "off");
class database {
	private $db_user;
	private $db_password;
	private $db_host;
	private $db_name;
	public $db_connection;
	function __construct($host, $name, $password, $user) {
		$this->db_host = $host;
		$this->db_name = $name;
		$this->db_password = $password;
		$this->db_user = $user;
		$this->db_connection = "";
	}
	public function connect() {
		$this->db_connection = mysqli_connect($this->db_host, $this->db_user, $this->db_password, $this->db_name);
		mysqli_set_charset($this->db_connection, 'utf8');
	}
	public function set($query) {
		@mysqli_query($this->db_connection, $query) or die(mysqli_error($this->db_connection));
	}
	public function get($query) {
		$result = mysqli_query($this->db_connection, $query) or die(mysqli_error($this->db_connection));
		$returnarray = array ();
		while ($row = mysqli_fetch_array($result)) {
			$returnarray[] = $row;
		}
		return $returnarray;
	}
	public function count($query) {
		$result = mysqli_query($this->db_connection, $query) or die(mysqli_error($this->db_connection));
		$rows = mysqli_num_rows($result);
		return $rows;
	}
	public function get_id() {
		return mysqli_insert_id($this->db_connection);
	}
}
function mres($value) {
	$output = $value;
	$output = str_replace('"', "", $output);
	$output = str_replace("'", "", $output);
    $search = array("\\",  "\x00", "\n",  "\r",  "'",  '"', "\x1a");
    $replace = array("\\\\","\\0","\\n", "\\r", "\'", '\"', "\\Z");
    $output = str_replace($search, $replace, $output);
    return $output;
}
function flush_buffers(){ 
    ob_end_flush(); 
    ob_flush(); 
    flush(); 
    ob_start(); 
} 






ob_start();
$db = new database('127.0.0.1', 'snippets', '', 'root');
$db->connect();

for ($i = 280847; $i < 337928; $i = $i + 1) {
	$url = "https://snipplr.com/view/".$i."?codeview=";
	echo "Processing ".$i."... (".$url.") ";
	flush_buffers();
	if (($homepage = @file_get_contents($url)) === false) {
		  $error = error_get_last();
		  echo "Error (" . $error['message'].")";
	} else {
		$dom = new domDocument;
		@$dom->loadHTML($homepage);
		// Title
		$figures = $dom->getElementsByTagName('title');
		$source_title = $dom->saveHtml($figures[0]);
		$source_title = str_replace('<title>', '', $source_title);
		$source_title = str_replace('</title>', '', $source_title);
		if ($source_title != 'Snipplr - Login') {
			echo " exists... ";
			
			// Description
			$source_description = substr($homepage, strrpos($homepage, '<div class="description">'), -1);
			$source_description = str_replace('<div class="description">', '', $source_description);
			$source_description = substr($source_description, 0, strpos($source_description, '</div>'));
			
			// Tag
			$source_tag = substr($homepage, strrpos($homepage, 'Published in: '), -1);
			$source_tag = str_replace('Published in: ', '', $source_tag);
			$source_tag = substr($source_tag, 0, 500);
			$source_tag = substr($source_tag, strrpos($source_tag, '/all?language='), -1);
			$source_tag = str_replace('/all?language=', '', $source_tag);
			$source_tag = substr($source_tag, 0, strrpos($source_tag, '</a>'));
			$source_tag = str_replace('</a>', '', $source_tag);
			$source_tag = substr($source_tag, 0, strrpos($source_tag, '">'));
			$source_tag = str_replace('">', '', $source_tag);			
			
			// Source code
			$figures = $dom->getElementsByTagName('textarea');
			$source_code = $dom->saveHtml($figures[0]);
			$source_code = str_replace('<textarea rows="25" class="copysource">', '', $source_code);
			$source_code = str_replace('</textarea>', '', $source_code);
			// File save			
			$myfile = fopen("source/".$i.".txt", "w") or die("Unable to open file!");
			fwrite($myfile, $source_code);
			fclose($myfile);
			// Database 
			$sql = "INSERT INTO `snipplr` (`id`, `title`, `description`, `tag`, `loc`, `snipplr_id`) VALUES (NULL, '".mres($source_title)."', '".mres($source_description)."', '".$source_tag."', '".(substr_count( $source_code, "\n" )+1)."', '".$i."'); ";
			$result = $db->set($sql);
		} else {
			echo " NOT exists or deleted... ";
		}
	}
	//sleep(1);
	flush_buffers();
	echo "<br/>";
}









?>
