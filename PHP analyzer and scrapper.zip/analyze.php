<?php
ini_set("max_execution_time", 0);
//ini_set("display_errors", "off");
class database {
	private $db_user;
	private $db_password;
	private $db_host;
	private $db_name;
	public $db_connection;
	function __construct($host, $name, $password, $user) {
		$this->db_host = $host;
		$this->db_name = $name;
		$this->db_password = $password;
		$this->db_user = $user;
		$this->db_connection = "";
	}
	public function connect() {
		$this->db_connection = mysqli_connect($this->db_host, $this->db_user, $this->db_password, $this->db_name);
		mysqli_set_charset($this->db_connection, 'utf8');
	}
	public function set($query) {
		@mysqli_query($this->db_connection, $query) or die(mysqli_error($this->db_connection));
	}
	public function get($query) {
		$result = mysqli_query($this->db_connection, $query) or die(mysqli_error($this->db_connection));
		$returnarray = array ();
		while ($row = mysqli_fetch_array($result)) {
			$returnarray[] = $row;
		}
		return $returnarray;
	}
	public function count($query) {
		$result = mysqli_query($this->db_connection, $query) or die(mysqli_error($this->db_connection));
		$rows = mysqli_num_rows($result);
		return $rows;
	}
	public function get_id() {
		return mysqli_insert_id($this->db_connection);
	}
}
function mres($value) {
	$output = $value;
	$output = str_replace('"', "", $output);
	$output = str_replace("'", "", $output);
    $search = array("\\",  "\x00", "\n",  "\r",  "'",  '"', "\x1a");
    $replace = array("\\\\","\\0","\\n", "\\r", "\'", '\"', "\\Z");
    $output = str_replace($search, $replace, $output);
    return $output;
}
function flush_buffers(){ 
    ob_end_flush(); 
    ob_flush(); 
    flush(); 
    ob_start(); 
} 






ob_start();
$db = new database('127.0.0.1', 'snippets', '', 'root');
$db->connect();

	$sql = "SELECT * FROM `snipplr`;";
	$dbresult = $db->get($sql);
//25917

for ($i = 1; $i <= 25917; $i = $i + 1) {
	echo "Processing ".$i."/25917... ";
	flush_buffers();
	
	// AI: "data/ai".$dbresult[$i]['snipplr_id'].".txt"
	// HUMAN: "data/".$dbresult[$i]['snipplr_id'].".txt"
	$file_analyzed = "source/ai".$dbresult[$i]['snipplr_id'].".txt";
	
	$METRIC_LOC = 0;
	$METRIC_EMPTY_LINES = 0;
	$METRIC_COMMENTS = 0;
	$METRIC_FUNCTIONS = 0;
	$METRIC_CLASSES = 0;
	$METRIC_LOOPS_FOR = 0;
	$METRIC_LOOPS_WHILE = 0;
	$METRIC_IF = 0;
	$METRIC_SWITCH = 0;
	$METRIC_CC = 0;
	$METRIC_HALSTEAD_UNIQUE_OPERATORS_N1 = 0;
	$METRIC_HALSTEAD_UNIQUE_OPERANDS_N2 = 0;
	$METRIC_HALSTEAD_TOTAL_OPERATORS = 0;
	$METRIC_HALSTEAD_TOTAL_OPERANDS = 0;
	$METRIC_HALSTEAD_VOCABULARY = 0;
	$METRIC_HALSTEAD_PROGRAM_LENGTH = 0;
	$METRIC_HALSTEAD_VOLUME = 0;
	$METRIC_HALSTEAD_DIFFICULTY = 0;
	$METRIC_HALSTEAD_EFFORT = 0;
	$METRIC_HALSTEAD_TIME = 0;
	$METRIC_HALSTEAD_ESTIMATED_BUGS = 0;
	$METRIC_MAINTAINABILITY_INDEX = 0;
		
    $operatorsList = ['+', '-', '*', '/', '%', '++', '--', '=', '+=', '-=', '*=', '/=', '%=', '==', '!=', '>', '<', '>=', '<=', '===', '!==', '&&', '||', '!', '&', '|', '^', '~', '<<', '>>', '?', ':', '.', '->', '::', '(', ')', '[', ']', '{', '}', ';', ','];
    $keywordsAsOperators = ['if', 'else', 'while', 'for', 'switch', 'case', 'return', 'new', 'try', 'catch'];
    $n1_unique = []; // Unique Operators
    $n2_unique = []; // Unique Operands
    $N1_total = 0;   // Total Operators
    $N2_total = 0;   // Total Operands
	if (file_exists($file_analyzed)) {
		$myfile = fopen($file_analyzed, "r") or die("Unable to open file!");
		while(!feof($myfile)) { $line = fgets($myfile);
			// METRIC_LOC
			$METRIC_LOC++;
			// METRIC_EMPTY_LINES
			if (empty(trim($line))) { $METRIC_EMPTY_LINES++; }			
			// METRIC_COMMENTS
			if (str_starts_with(trim($line), '//') || str_starts_with(trim($line), '#') || str_starts_with(trim($line), '/*') || str_starts_with(trim($line), '{-') || str_starts_with(trim($line), '<!--')  || str_starts_with(trim($line), 'TODO') || str_starts_with(trim($line), '&lt;?') || str_starts_with(trim($line), '?&gt;') ) { $METRIC_COMMENTS++; }
			// METRIC_FUNCTIONS
			if (str_contains($line, 'def ') || str_contains($line, 'function ') || str_contains($line, '=> ') || str_contains($line, ') {') || str_contains($line, '){') || str_contains($line, 'fn ') || str_contains($line, 'func ')) { $METRIC_FUNCTIONS++; }
			// METRIC_CLASSES
			if (str_contains($line, 'class ')) { $METRIC_CLASSES++; }
			// METRIC_LOOPS_FOR
			if (str_contains($line, 'for ')) { $METRIC_LOOPS_FOR++; }
			// METRIC_LOOPS_WHILE
			if (str_contains($line, 'while ')) { $METRIC_LOOPS_WHILE++; }
			// METRIC_IF
			if (str_contains($line, 'if ')) { $METRIC_IF++; }
			// METRIC_SWITCH
			if (str_contains($line, 'switch ') || str_contains($line, 'match ')) { $METRIC_SWITCH++; }
			// METRIC_CC
			if (str_contains($line, '&&') || str_contains($line, '||') || str_contains($line, '?:') || str_contains($line, '??')) { $METRIC_CC++; }
			// HALSTEAD
			$line = preg_replace('!/\*.*?\*/!s', '', $line);
			$line = preg_replace('!//.*!', '', $line);
			$line = trim($line);
			if (empty($line)) continue;
			preg_match_all('/[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*|[0-9.]+|==|!=|>=|<=|&&|\|\||\+\+|--|->|::|[\+\-\*\/\%\=\>\<\|\&\^\!\~\? \: \. \(\)\[\]\{\}\;\,\,]/', $line, $matches);
			foreach ($matches[0] as $token) {
				$token = trim($token);
				if ($token === '') continue;
				if (in_array($token, $operatorsList) || in_array($token, $keywordsAsOperators)) {
					$N1_total++;
					$n1_unique[$token] = true;
				} else {
					$N2_total++;
					$n2_unique[$token] = true;
				}
			}
		}
		$METRIC_CC = $METRIC_CC + $METRIC_LOOPS_FOR + $METRIC_LOOPS_WHILE + $METRIC_IF + $METRIC_SWITCH;
		$n1 = count($n1_unique);
		$n2 = count($n2_unique);
		$n = $n1 + $n2;
		$N = $N1_total + $N2_total;
		$V = ($n > 0) ? $N * log($n, 2) : 0;
		$D = ($n2 > 0) ? ($n1 / 2) * ($N2_total / $n2) : 0;
		$E = $D * $V;
		$T = $E / 18;
		$B = $V / 3000;
		$METRIC_HALSTEAD_UNIQUE_OPERATORS_N1 = $n1;
		$METRIC_HALSTEAD_UNIQUE_OPERANDS_N2 = $n2;
		$METRIC_HALSTEAD_TOTAL_OPERATORS = $N1_total;
		$METRIC_HALSTEAD_TOTAL_OPERANDS = $N2_total;
		$METRIC_HALSTEAD_VOCABULARY = $n;
		$METRIC_HALSTEAD_PROGRAM_LENGTH = $N;
		$METRIC_HALSTEAD_VOLUME = $V;
		$METRIC_HALSTEAD_DIFFICULTY = $D;
		$METRIC_HALSTEAD_EFFORT = $E;
		$METRIC_HALSTEAD_TIME = $T;
		$METRIC_HALSTEAD_ESTIMATED_BUGS = $B;
		$METRIC_MAINTAINABILITY_INDEX = 171 - (5.2 * log($METRIC_HALSTEAD_VOLUME)) - (0.23 * $METRIC_CC) - (16.2 * log(abs($METRIC_LOC - $METRIC_EMPTY_LINES - $METRIC_COMMENTS)));;
		
		$sql = "UPDATE `snipplr` SET `AI_METRIC_LOC` = '".$METRIC_LOC."', `AI_METRIC_EMPTY_LINES` = '".$METRIC_EMPTY_LINES."', `AI_METRIC_COMMENTS` = '".$METRIC_COMMENTS."', `AI_METRIC_FUNCTIONS` = '".$METRIC_FUNCTIONS."', `AI_METRIC_CLASSES` = '".$METRIC_CLASSES."', `AI_METRIC_LOOPS_FOR` = '".$METRIC_LOOPS_FOR."', `AI_METRIC_LOOPS_WHILE` = '".$METRIC_LOOPS_WHILE."', `AI_METRIC_IF` = '".$METRIC_IF."', `AI_METRIC_SWITCH` = '".$METRIC_SWITCH."', `AI_METRIC_CC` = '".$METRIC_CC."', `AI_METRIC_HALSTEAD_UNIQUE_OPERATORS_N1` = '".$METRIC_HALSTEAD_UNIQUE_OPERATORS_N1."', `AI_METRIC_HALSTEAD_UNIQUE_OPERANDS_N2` = '".$METRIC_HALSTEAD_UNIQUE_OPERANDS_N2."', `AI_METRIC_HALSTEAD_TOTAL_OPERATORS` = '".$METRIC_HALSTEAD_TOTAL_OPERATORS."', `AI_METRIC_HALSTEAD_TOTAL_OPERANDS` = '".$METRIC_HALSTEAD_TOTAL_OPERANDS."', `AI_METRIC_HALSTEAD_VOCABULARY` = '".$METRIC_HALSTEAD_VOCABULARY."', `AI_METRIC_HALSTEAD_PROGRAM_LENGTH` = '".$METRIC_HALSTEAD_PROGRAM_LENGTH."', `AI_METRIC_HALSTEAD_VOLUME` = '".$METRIC_HALSTEAD_VOLUME."', `AI_METRIC_HALSTEAD_DIFFICULTY` = '".$METRIC_HALSTEAD_DIFFICULTY."', `AI_METRIC_HALSTEAD_EFFORT` = '".$METRIC_HALSTEAD_EFFORT."', `AI_METRIC_HALSTEAD_TIME` = '".$METRIC_HALSTEAD_TIME."', `AI_METRIC_HALSTEAD_ESTIMATED_BUGS` = '".$METRIC_HALSTEAD_ESTIMATED_BUGS."', `AI_METRIC_MAINTAINABILITY_INDEX` = '".$METRIC_MAINTAINABILITY_INDEX."' WHERE `snipplr`.`id` = ".$i.";";
		$result = $db->set($sql);
		
		/*

	UPDATE `snipplr` SET `AI_METRIC_LOC` = '1', `AI_METRIC_EMPTY_LINES` = '1', `AI_METRIC_COMMENTS` = '1', `AI_METRIC_FUNCTIONS` = '1', `AI_METRIC_CLASSES` = '1', `AI_METRIC_LOOPS_FOR` = '1', `AI_METRIC_LOOPS_WHILE` = '1', `AI_METRIC_IF` = '1', `AI_METRIC_SWITCH` = '1', `AI_METRIC_CC` = '1', `AI_METRIC_HALSTEAD_UNIQUE_OPERATORS_N1` = '1', `AI_METRIC_HALSTEAD_UNIQUE_OPERANDS_N2` = '1', `AI_METRIC_HALSTEAD_TOTAL_OPERATORS` = '1', `AI_METRIC_HALSTEAD_TOTAL_OPERANDS` = '1', `AI_METRIC_HALSTEAD_VOCABULARY` = '1', `AI_METRIC_HALSTEAD_PROGRAM_LENGTH` = '1', `AI_METRIC_HALSTEAD_VOLUME` = '1', `AI_METRIC_HALSTEAD_DIFFICULTY` = '1', `AI_METRIC_HALSTEAD_EFFORT` = '1', `AI_METRIC_HALSTEAD_TIME` = '1', `AI_METRIC_HALSTEAD_ESTIMATED_BUGS` = '1', `AI_METRIC_MAINTAINABILITY_INDEX` = '1' WHERE `snipplr`.`id` = 1;
	
	$AI_METRIC_LOC = 0;
	$AI_METRIC_EMPTY_LINES = 0;
	$AI_METRIC_COMMENTS = 0;
	$AI_METRIC_FUNCTIONS = 0;
	$AI_METRIC_CLASSES = 0;
	$AI_METRIC_LOOPS_FOR = 0;
	$AI_METRIC_LOOPS_WHILE = 0;
	$AI_METRIC_IF = 0;
	$AI_METRIC_SWITCH = 0;
	$AI_METRIC_CC = 0;
	$AI_METRIC_HALSTEAD_UNIQUE_OPERATORS_N1 = 0;
	$AI_METRIC_HALSTEAD_UNIQUE_OPERANDS_N2 = 0;
	$AI_METRIC_HALSTEAD_TOTAL_OPERATORS = 0;
	$AI_METRIC_HALSTEAD_TOTAL_OPERANDS = 0;
	$AI_METRIC_HALSTEAD_VOCABULARY = 0;
	$AI_METRIC_HALSTEAD_PROGRAM_LENGTH = 0;
	$AI_METRIC_HALSTEAD_VOLUME = 0;
	$AI_METRIC_HALSTEAD_DIFFICULTY = 0;
	$AI_METRIC_HALSTEAD_EFFORT = 0;
	$AI_METRIC_HALSTEAD_TIME = 0;
	$AI_METRIC_HALSTEAD_ESTIMATED_BUGS = 0;
	$AI_METRIC_MAINTAINABILITY_INDEX = 0;
		*/
		
		flush_buffers();
	}
	echo "OK<br/>";
}


?>
